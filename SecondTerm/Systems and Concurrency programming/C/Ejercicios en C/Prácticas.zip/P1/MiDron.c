#include "gestion_memoria.h"
#include <stdio.h>
#include <stdlib.h>

#define MAX 999;

void crear (T_Manejador *manejador){
    (*manejador) = (T_Manejador) malloc (sizeof(struct T_Nodo));
    (*manejador)->fin= MAX ;
    (*manejador)->inicio=0;
    (*manejador)->sig = NULL;
}

void destruir (T_Manejador *manejador){
    
    //De forma recursiva 

    if((*manejador)!=NULL){
        T_Manejador ptr = (*manejador)->sig;
        free(*manejador);
        destruir(&ptr);
        (*manejador) = NULL;

    }
    // T_Manejador ptr;

    // while((*manejador)!=NULL){
        
    //     ptr= (*manejador);
    //     (*manejador) = (*manejador)->sig;
    //     free(ptr);

    // }
}

void obtener(T_Manejador *manejador, unsigned tam, unsigned *dir, unsigned *ok)
{

    T_Manejador ant, ptr;
    *ok = 0;
    ant= NULL;
    ptr= *manejador;

    while (ptr!=NULL && !(*ok)){
        //Iteramos en la lista hasta que necontremos tamaño suficiente para meter el archivo
        unsigned tam_actual= (ptr->fin)-(ptr->inicio) +1;

        if (tam <= tam_actual){
            (*ok)= 1; //hemos encontrado espacio
        }else{
            //seguimos en la lista
            ant= ptr;
            ptr= ptr->sig;
        }

    } 

    if((*ok)){
        //hemos encontrado un espacio
        *dir = ptr->inicio;
        //Tomamos el tamaño disponible 
        unsigned tam_actual= (ptr->fin)-(ptr->inicio) +1;
         
        if (tam == tam_actual){
            //Ocupa todo el espacio
            if (ant ==NULL){
                //Estamos al inicio de la lista
                ant =  (*manejador);
                (*manejador) = (*manejador)->sig ;
            }
                //nodo intermedio o final
                ant->sig= ptr->sig;
        }else{//toma una parte del almacenamiento del nodo
            ptr->inicio= ptr->inicio + tam;
        }

    }
    

}

void mostrar(T_Manejador manejador)
{
    printf ("----------------- \n");

    while (manejador!=NULL){
        printf("Desde %d a %d : Libre\n",manejador->inicio,manejador->fin);
        manejador= manejador->sig;
    }

    fflush(stdout);

}


void devolver(T_Manejador *manejador, unsigned tam, unsigned dir)
{
    T_Manejador ant, ptr;
    ant= NULL;
    ptr= *manejador;
    

    while (ptr!=NULL && dir > (ptr->inicio)){
        ant=ptr;
        ptr= ptr->sig;
    }

    T_Manejador nuevo;
    nuevo = (T_Manejador) malloc (sizeof(struct T_Nodo));

    nuevo->inicio= dir;
    nuevo->fin= dir + tam - 1;
    nuevo->sig = ptr;

    if(ant== NULL){
        (*manejador)= nuevo;

    }else{
        ant->sig = nuevo;
    }

}

/*MODIFICAR EL NODO CON DIR ESPECÍFICA
Este caso se da cuando en el método devolver la dirección pasada toma una parte intermedia del nodo
    Ejemplo:
        *Espacio disponible : 0 999
                Espacio a tomar->50 100
            Lista resultante : 0 49 , 101 999
                Pasos a seguir 
                    1- Modificar el apartado fin del primer nodo guardando el valor fin original
                    2- crear un nuevo nodo con el apartado inicio = tamaño+dir+1 y el final con el guardado
                    3- enlazar nodos
        *Espacio disponible : 0 999
                Espacio a tomar -> 0 10
            En este caso solo debemos de modificar el valor de inicio
            Lista resultante : 11 999 
        *Espacio disponible : 0 999
                Espacio a tomar -> 980 999
            En este caso solo modificamos el valor de final 
            Lista resultante :0 979
*/

/*
Para recorrer los elementos del objeto T_Manejador necesitaremos:
        -Dos punteros ant (anterior) y aux (auxiliar)
            +   T_Manejador ant, aux,
        
        -Inicializamos ambos punteros:
            + ptr =(*manejador);
            + ant = NULL
        -buscar la posición donde insertaro eliminar:
            + Bucle while condición haciendo 
                ... 
                ant = ptr;
                ptr = ptr -> sig;
        -Según los valores de ptr y ant
            if(ant == NULL){  //ptr apunta al principio de la lista
                ...
            }else{            //ptr apunta a un elemento distinto del primero
                if(ptr==NULL) // ant apunta al ultimo elemento
            }
*/
