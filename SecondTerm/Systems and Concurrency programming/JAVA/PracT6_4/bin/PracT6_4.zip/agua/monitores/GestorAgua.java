package agua.monitores;
import java.util.concurrent.locks.*;

public class GestorAgua {
	private Lock l= new ReentrantLock();
	private Condition atomo= l.newCondition();
	private Condition h = l.newCondition();
	private Condition o= l.newCondition();
	
	private int num_hidrog= 0;
	private boolean un_oxig= false;
	private boolean barrera_atom=false;
	

	public void hListo(int id) throws InterruptedException { 
		try {
			l.lock();
			while(num_hidrog==2) {
				h.await();
			}
			num_hidrog++;
			if(num_hidrog==2 && un_oxig) {
				barrera_atom=true;
				atomo.signalAll();
			}
			while(!barrera_atom) {
				atomo.await();
			}
			num_hidrog--;
			
			if(!un_oxig && num_hidrog==0) {
				o.signalAll();
				h.signalAll();
				barrera_atom=false;
			}
		} finally {
			// TODO: handle finally clause
			l.unlock();
		}
	}
	
	public void oListo(int id) throws InterruptedException { 
		try {
			l.lock();
			while(un_oxig) {
				o.await();
			}
			un_oxig=true;
			
			if(num_hidrog==2 && un_oxig) {
				barrera_atom=true;
				atomo.signalAll();
			}
			while(!barrera_atom) {
				atomo.await();
			}
			un_oxig=false;
			
			if(!un_oxig && num_hidrog==0) {
				o.signalAll();
				h.signalAll();
				barrera_atom=false;
			}
		} finally {
			// TODO: handle finally clause
			l.unlock();
		}
	}
}
