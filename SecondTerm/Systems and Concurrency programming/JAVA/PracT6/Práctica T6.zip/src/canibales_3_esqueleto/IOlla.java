package canibales_3_esqueleto;

public interface IOlla {
	public void nuevoExplorador() throws InterruptedException;

	public void comeRacion(int id) throws InterruptedException;
}
