/**
UNIX Shell Project

Sistemas Operativos
Grados I. Informatica, Computadores & Software
Dept. Arquitectura de Computadores - UMA

Some code adapted from "Fundamentos de Sistemas Operativos", Silberschatz et al.

To compile and run the program:
   $ gcc Shell_project.c job_control.c -o Shell
   $ ./Shell          
	(then type ^D to exit program)

**/

#include "job_control.h"   // remember to compile with module job_control.c 
#include "parse_redir.h"
#include <string.h>
#include <fcntl.h>

#define MAX_LINE 256 /* 256 chars per line, per command, should be enough. */
// -----------------------------------------------------------------------
//                            TAREA 3          
// -----------------------------------------------------------------------
job * lista;
int shell_pid;

void manejador (int senal)
{
    block_SIGCHLD();
	pid_t pid;
	int status_pid=0, info=0;
	enum status status_res;
	job * proceso;
	int borrar ;
	
	
	while((pid= waitpid(-1, &status_pid,(WNOHANG | WUNTRACED | WCONTINUED)))>0)
	{
		status_res= analyze_status(status_pid, &info);
		
		
		proceso= get_item_bypid(lista,pid);
		if(proceso!=NULL)
		{
			if (status_res == SUSPENDED )
			{
				proceso->state = STOPPED;
			}else if (status_res == CONTINUED )
			{
				proceso->state = BACKGROUND;
			} else if(status_res == EXITED || status_res == SIGNALED ) //Eliminar proceso de la lista
			{			
				borrar = delete_job(lista, proceso);
				if(borrar==0)
				{
					perror("No se pudo eliminar el proceso de la lista de procesos background");
				}
			
			}
			
		}
		//printf("Manejador,pid: %d, command: %s, %s, info: %d \n",proceso->pgid ,proceso->command ,status_strings[status_res],info);
		
	}
	unblock_SIGCHLD() ;
	
	

}
// -----------------------------------------------------------------------
//                  	FACTORIZACIÓN DEL CÓDIGO          
// -----------------------------------------------------------------------

void proceso_hijo (int background,char * args[],char * filein,char * fileout)
{
	new_process_group( getpid()); //Crear un grupo de procesos en función dela id del proceso hijo
			
	//Asociamos al foreground del terminal el proceso hijo
	if(background==0)tcsetpgrp(STDIN_FILENO, getpid());
			
	restore_terminal_signals();  // pertimos las señales de job_control.c para así poder mandar señales al hijo
			
	// -----------------------------------------------------------------------
	//                            TAREA 5          
	// -----------------------------------------------------------------------
	if(filein != NULL)
	{	
		int in_fno =open(filein,O_RDONLY); //Te da el numero del pos mem
		//Comprobar si el método no funciono
		if(in_fno==-1)
		{
			perror("open_in");
			exit(EXIT_FAILURE);
		}
				
		//Hacemos una copia del fcihero
		//Hay que controlar que dup2 de -1 sigifica error
		if(dup2(in_fno,STDIN_FILENO)==-1)
		{
			perror("Dup2: file in");
			exit(EXIT_FAILURE) ;
		}
		close(in_fno);
	}
			
	if(fileout !=NULL)
	{
		int out_fno= open (fileout,O_WRONLY | O_CREAT,0666); // 0x666 wrx usuario
		if(out_fno==-1)
		{
			perror("open_out");
			exit(EXIT_FAILURE) ;
		}
				
		//Hacemos una copia del fcihero
		//Hay que controlar que dup2 de -1 sigifica error
		if(dup2(out_fno,STDOUT_FILENO)==-1)
		{
			perror("Dup2: file out");
			exit(EXIT_FAILURE) ;
		}
			
				
		close(out_fno);
	}
					
			
	if(execvp(args[0],args)==-1)
	{				
		printf("Error, command not found: %s \n",args[0]);
		exit(EXIT_FAILURE) ;
			
	}
			
			
}

void background_process (int pid_fork,char * args[],job * nodo)
{
	block_SIGCHLD();
	//Creamos un nodo del proceso background y lo añadimos a la lista
	nodo = new_job(pid_fork, args[0],BACKGROUND);
	add_job (lista,nodo);
			
	printf("Background job running... pid: %d,command: %s \n",pid_fork,args[0]);
				
	unblock_SIGCHLD() ;
}

void foreground_process(int pid_fork,char * args[],job * nodo)
{
	int pid_wait;
	enum status status_res;
	int status;
	int info;

	//El proceso obtiene el control del terminal
	tcsetpgrp(STDIN_FILENO,pid_fork);
				
	//RETURN: 
	//	*It returns the process ID of the stopped child process.
	//	*If it fails returns -1

	pid_wait=waitpid(pid_fork,&status,WUNTRACED);
				
				
				
	if(pid_wait ==-1)
	{
		printf("\nError in waitpid");
		exit(EXIT_FAILURE);
	}else
	{
		//Colocamos en foreground el proceso de nuestro terminal
		tcsetpgrp(STDIN_FILENO,shell_pid);
		
		//Evaluamos el motivo de terminación del proceso hijo e imprimimos 
		status_res= analyze_status(status, &info);

		//Imprimimos el mensaje con información del proceso		
		printf("Foreground pid: %d, command: %s, %s, info: %d \n",pid_wait,args[0],status_strings[status_res],info);
		//Si el proceso ha sido parado hay que añadirlo a la lista de background
		if (status_res == STOPPED){
			block_SIGCHLD();
			nodo = new_job(pid_wait, args[0], STOPPED);
			add_job(lista, nodo);
			unblock_SIGCHLD();
			}
	}
}

void proceso_padre (int pid_fork,int background,char * args[],job * nodo)
{
	//RETURN: La variable background tomará los valores 0 y 1 los cuales informan de:
	//	* 0: El proceso está en foreground
	//	* 1: El proceso está en background
	if(background==1)
	{
		background_process(pid_fork,args, nodo);
	}else
	{
		foreground_process(pid_fork,args,nodo);
	}
}

void proceso_fork (job * nodo,int background, char * args[],int argc,char * filein,char * fileout)
{
	int pid_fork;
	/*RETURN:
		On success, the PID of the child process is returned in the
       parent, and 0 is returned in the child.  On failure, -1 is
       returned in the parent, no child process is created, and errno is
       set to indicate the error.
	*/
	pid_fork = fork(); 
	
	if(pid_fork==-1)
	{
		//fork fallido
		perror("Fork have not succeeded");
	}else if (pid_fork==0)
	{
		//Proceso hijo
		proceso_hijo(background,args,filein,fileout);

	}else
	{
		//Proceso padre
		proceso_padre(pid_fork,background,args,nodo);
	}


}
// -----------------------------------------------------------------------
//                            MAIN          
// -----------------------------------------------------------------------

int main(int argc, char*env[])
{
	char inputBuffer[MAX_LINE]; /* buffer to hold the command entered */
	int background;             /* equals 1 if a command is followed by '&' */
	char *args[MAX_LINE/2];     /* command line (of 256) has max of 128 arguments */
	// probably useful variables:
	int pid_fork, pid_wait; /* pid for created and waited process */
	int status;             /* status returned by wait */
	enum status status_res; /* status processed by analyze_status() */
	int info;				/* info processed by analyze_status() */
	
	

	// -----------------------------------------------------------------------
	//                            TAREA 3          
	// -----------------------------------------------------------------------
	//Inicializamos la lista de procesos background
	lista= new_list("lista");
	ignore_terminal_signals();
	signal(SIGCHLD,manejador);
	
	shell_pid= getpid();

	while (1)   /* Program terminates normally inside get_command() after ^D is typed*/
	{   		
		printf("COMMAND->");
		fflush(stdout);
		get_command(inputBuffer, MAX_LINE, args, &background);  /* get next command */
		
		// -----------------------------------------------------------------------
		//                            TAREA 5          
		// -----------------------------------------------------------------------
		//Obtenemos los nombres de fichero para pasarlos por la funcion procesos_fork
		char * filein, * fileout;
		parse_redirections(args,&filein,&fileout);

		if(args[0]==NULL) continue;   // if empty command

		// -----------------------------------------------------------------------
		//                            TAREA 2          
		// -----------------------------------------------------------------------
		//Implementar el comando interno cd para permitir cambiar el directorio
		//de trabajo actual (usar la función chdir).
		
		if(strcmp(args[0],"cd")==0)
		{
			//Se ejecuta el comando y si devuelve -1 devuelve un error
			if(chdir(args[1])== -1)
			{
				perror("Path");
			}
			
			continue;
		}
		
		// -----------------------------------------------------------------------
		//                            TAREA 4          
		// -----------------------------------------------------------------------
		//Se debe implementar de forma segura la gestión de tareas en
		//segundo plano o background

		job * nodo;
		job * tarea;
		//int foregrnd= 0;
		//Imprimimos la lista de procesos background
		if(strcmp(args[0],"jobs")==0)
		{
				block_SIGCHLD();
				//Utiliza la función print_list implementada en job_control.h
				print_list(lista,print_item);
				unblock_SIGCHLD();

				continue;
		}

		//Pasamos un proceso foreground a background
		if(strcmp(args[0], "bg")==0)
		{
			block_SIGCHLD();
			//Diferenciamos si nos pansan bg o bg num
			int pos =(args[1]!=NULL)?atoi(args[1]):1;
			
			//Buscamos el nodo en la lista de procesos background
			nodo=get_item_bypos(lista,pos);
			

			// Si lo hemos encontrado y su estado es parado se pasa a Background
			if(nodo!=NULL && nodo->state == STOPPED)
			{
				nodo->state = BACKGROUND;
				killpg(nodo->pgid,SIGCONT);
				
			}
			unblock_SIGCHLD();

			continue;
		}
		//Pasamos un proceso background a foreground
		if (strcmp(args[0],"fg")==0)
		{
			block_SIGCHLD();
			//Diferenciamos si nos pansan fg o fg num
			int pos =(args[1]!=NULL)?atoi(args[1]):1;
			
			//Buscamos el nodo en la lista de procesos background
			nodo = get_item_bypos(lista,pos);

			// Si lo hemos encontrado
			if(nodo !=NULL)
			{
				//foregrnd=1;
				//Colocanos el proceso en foreground 
				tcsetpgrp(STDIN_FILENO,nodo->pgid);

				
				if(nodo->state == STOPPED)
				{
					killpg(nodo->pgid,SIGCONT);
				}
				
				
				//hacemos una copia del proceso para el proceso padre
				pid_fork= nodo->pgid;
				strcpy(args[0],nodo->command);

				//Guardamos los datos correspondientes para mandarselos al proceso padre
				tarea= new_job(pid_fork,args[0],nodo->state);

				delete_job(lista, nodo);

				//LLAMAR AL PROCESO PADRE//
				proceso_padre(pid_fork,0,args,tarea);
			
			}
			unblock_SIGCHLD();
			continue;
			
		}

		proceso_fork(nodo,background,args,argc,filein,fileout);

	} // end while
}
