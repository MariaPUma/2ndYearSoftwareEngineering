#include <iostream>
#include <array>
using namespace std;
const int MAX = 10;
typedef array<int, MAX>TArray;

struct TEnteros{
TArray numeros;
int numElem;

};
void Leer (TEnteros& num){
    int pos =0;
cout<< "Por favor introduzca los numeros que desea introducir en la secuencia : ";
cin >> pos;


num.numElem=0;

    for (; ; )
        ;


}

int main (){

TEnteros num;

Leer (num);



return 0 ;
}
